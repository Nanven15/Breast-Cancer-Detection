# Breast-Cancer-Detection-using-KNN-Naive-Bayes
Our project for seminar 

Dataset used - Wisconsin
